---
name: order-lookup
description: Look up an order by id.
---
Call the orders API with the order id.
